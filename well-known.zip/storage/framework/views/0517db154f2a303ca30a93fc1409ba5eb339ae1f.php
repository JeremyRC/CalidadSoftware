<div class="table-responsive">
    <table class="table text-center" id="example">
        <thead>
            <tr>
                <th>Grado</th>
                <th>Seccion</th>
                <th>Accion</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $aulas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($aula->grado->descripcion); ?></td>
                <td><?php echo e($aula->seccion); ?></td>
                <td>
                    <?php echo Form::open(['route' => ['aulas.destroy', $aula->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('aulas.show', [$aula->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                        <a href="<?php echo e(route('aulas.edit', [$aula->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                        <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div><?php /**PATH /home/eozckcvw/infoelite.misistema99.com/resources/views/aulas/table.blade.php ENDPATH**/ ?>