<!-- Idmatricula Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('idmatricula', 'Alumno:'); ?>

    <p><?php echo e($pagos->matricula->alumno->nombre." ".$pagos->matricula->alumno->apellidos); ?></p>
</div>

<!-- Numero Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('numero', 'Numero:'); ?>

    <p><?php echo e($pagos->numero); ?></p>
</div>

<!-- Mes Pension Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('mes_pension', 'Mes Pension:'); ?>

    <p><?php echo e($pagos->mes_pension); ?></p>
</div>

<!-- Monto Pension Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('monto_pension', 'Monto Pension:'); ?>

    <p><?php echo e($pagos->monto_pension); ?></p>
</div>

<!-- Monto Matricula Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('monto_matricula', 'Monto Matricula:'); ?>

    <p><?php echo e($pagos->monto_matricula); ?></p>
</div>

<!-- Monto Material Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('monto_material', 'Monto Material:'); ?>

    <p><?php echo e($pagos->monto_material); ?></p>
</div>

<!-- Monto Copias Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('monto_copias', 'Monto Copias:'); ?>

    <p><?php echo e($pagos->monto_copias); ?></p>
</div>

<!-- Monto Actividades Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('monto_actividades', 'Monto Actividades:'); ?>

    <p><?php echo e($pagos->monto_actividades); ?></p>
</div>

<!-- Created At Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('created_at', 'Creado en:'); ?>

    <p><?php echo e(date("d/m/Y h:i a", strtotime($pagos->created_at))); ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('updated_at', 'Actualizado en:'); ?>

    <p><?php echo e(date("d/m/Y h:i a", strtotime($pagos->updated_at))); ?></p>
</div>

<div class="form-group col-sm-6">
    <a href="<?php echo e(route('pagos.index')); ?>" class="btn btn-default">Atras</a>
</div><?php /**PATH /home/eozckcvw/infoelite.misistema99.com/resources/views/pagos/show_fields.blade.php ENDPATH**/ ?>