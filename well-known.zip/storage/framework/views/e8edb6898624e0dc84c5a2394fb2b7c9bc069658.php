<div class="table-responsive">
    <table class="table text-center" id="example">
        <thead>
            <tr>
                <th>Alumno</th>
                <th>Numero</th>
                <th>Mes</th>
                <th>Monto Pension</th>
                <th>Monto Matricula</th>
                <th>Monto Material</th>
                <th>Monto Copias</th>
                <th>Monto Actividades</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pagos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pagos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($pagos->matricula->alumno->nombre." ".$pagos->matricula->alumno->apellidos); ?></td>
                <td><?php echo e($pagos->numero); ?></td>
                <td><?php echo e($pagos->mes_pension); ?></td>
                <td><?php echo e($pagos->monto_pension); ?></td>
                <td><?php echo e($pagos->monto_matricula); ?></td>
                <td><?php echo e($pagos->monto_material); ?></td>
                <td><?php echo e($pagos->monto_copias); ?></td>
                <td><?php echo e($pagos->monto_actividades); ?></td>
                <td>
                    <?php echo Form::open(['route' => ['pagos.destroy', $pagos->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('pagos.show', [$pagos->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                        <a href="<?php echo e(route('pagos.edit', [$pagos->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                        <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div><?php /**PATH /home/eozckcvw/infoelite.misistema99.com/resources/views/pagos/table.blade.php ENDPATH**/ ?>