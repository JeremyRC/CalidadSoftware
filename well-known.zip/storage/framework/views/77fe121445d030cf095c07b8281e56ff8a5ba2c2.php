<li class="<?php echo e(Request::is('users*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('users.index')); ?>"><i class="fa fa-edit"></i><span>Usuarios</span></a>
</li>

<li class="<?php echo e(Request::is('matriculas*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('matriculas.index')); ?>"><i class="fa fa-edit"></i><span>Matricula</span></a>
</li>

<li class="<?php echo e(Request::is('pagos*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('pagos.index')); ?>"><i class="fa fa-edit"></i><span>Pagos</span></a>
</li>

<li class="<?php echo e(Request::is('aulas*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('aulas.index')); ?>"><i class="fa fa-edit"></i><span>Aula</span></a>
</li>

<!-- <li class="<?php echo e(Request::is('alumnos*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('alumnos.index')); ?>"><i class="fa fa-edit"></i><span>Alumnos</span></a>
</li> -->

<!-- <li class="<?php echo e(Request::is('apoderados*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('apoderados.index')); ?>"><i class="fa fa-edit"></i><span>Apoderado</span></a>
</li>

<li class="<?php echo e(Request::is('grados*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('grados.index')); ?>"><i class="fa fa-edit"></i><span>Grados</span></a>
</li>

<li class="<?php echo e(Request::is('privilegios*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('privilegios.index')); ?>"><i class="fa fa-edit"></i><span>Privilegios</span></a>
</li> --><?php /**PATH C:\Users\DIEGO\Desktop\Diego\laravel\infoelite\resources\views/layouts/menu.blade.php ENDPATH**/ ?>