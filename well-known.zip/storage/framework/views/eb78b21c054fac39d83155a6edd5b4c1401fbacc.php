<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1>
        Pagos
    </h1>
</section>
<div class="content">
    <?php echo $__env->make('adminlte-templates::common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="box box-danger">
        <div class="box-header with-border">
            <h3 class="box-title">Registro de Pagos</h3>
        </div>
        <div class="box-body">
            <div class="row">
                <?php echo Form::open(['route' => 'pagos.store']); ?>


                <?php echo $__env->make('pagos.fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DIEGO\Desktop\Diego\laravel\infoelite\resources\views/pagos/create.blade.php ENDPATH**/ ?>