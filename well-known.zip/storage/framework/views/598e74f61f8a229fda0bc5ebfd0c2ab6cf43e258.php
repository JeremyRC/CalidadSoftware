<!-- Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('name', 'Nombre:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

</div>

<!-- Email Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('email', 'Correo:'); ?>

    <?php echo Form::email('email', null, ['class' => 'form-control']); ?>

</div>

<!-- Password Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('password', 'Contraseña:'); ?>

    <?php echo Form::password('password', ['class' => 'form-control']); ?>

</div>

<!-- Privilegio Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('idprivilegio', 'Privilegio:'); ?>

    <?php echo Form::select('idprivilegio',$listPrivilegio, null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Guardar', ['class' => 'btn btn-danger']); ?>

    <a href="<?php echo e(route('users.index')); ?>" class="btn btn-default">Cancelar</a>
</div>
<?php /**PATH C:\Users\DIEGO\Desktop\Diego\laravel\infoelite\resources\views/users/fields.blade.php ENDPATH**/ ?>