<div class="table-responsive">
    <table class="table text-center" id="example">
        <thead>
            <tr>
                <th>Alumno</th>
                <th>Grado</th>
                <th>Seccion</th>
                <th>Apoderado</th>
                <th>Colegio Procedencia</th>
                <th>Accion</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $matriculas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matricula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($matricula->alumno->nombre." ".$matricula->alumno->apellidos); ?></td>
                <td><?php echo e($matricula->grado->descripcion); ?></td>
                <?php if(isset($matricula->aula->seccion)): ?>
                <td><?php echo e($matricula->aula->seccion); ?></td>
                <?php else: ?>
                <td>
                    <span class="badge bg-primary">PENDIENTE</span>
                </td>
                <?php endif; ?>
                <td><?php echo e($matricula->apoderado->nombres_a." ".$matricula->apoderado->apellidos_a); ?></td>
                <td><?php echo e($matricula->colegio_procedencia); ?></td>
                <td>
                    <?php echo Form::open(['route' => ['matriculas.destroy', $matricula->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('matriculas.show', [$matricula->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                        <a href="<?php echo e(route('matriculas.edit', [$matricula->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                        <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div><?php /**PATH C:\Users\DIEGO\Desktop\Diego\laravel\infoelite\resources\views/matriculas/table.blade.php ENDPATH**/ ?>