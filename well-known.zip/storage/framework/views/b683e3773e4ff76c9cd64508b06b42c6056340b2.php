<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1>
        Matricula
    </h1>
</section>
<div class="content">
    <?php echo $__env->make('adminlte-templates::common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo Form::model($matricula, ['route' => ['matriculas.update', $matricula->id], 'method' => 'patch']); ?>


    <?php echo $__env->make('matriculas.fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    setSeccion();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/eozckcvw/infoelite.misistema99.com/resources/views/matriculas/edit.blade.php ENDPATH**/ ?>