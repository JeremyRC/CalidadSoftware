<div class="box box-danger">
    <div class="box-header with-border">
        <h3 class="box-title">Datos del Estudiante</h3>
    </div>
    <div class="box-body">
        <div class="row">
            <!-- Nombre Field -->
            <div class="form-group col-sm-6">
                <?php echo Form::label('nombre', 'Nombre:'); ?>

                <?php if(isset($matricula->alumno)): ?>
                <?php echo Form::text('nombre', $matricula->alumno->nombre, ['class' => 'form-control']); ?>

                <?php else: ?>
                <?php echo Form::text('nombre', null, ['class' => 'form-control']); ?>

                <?php endif; ?>
            </div>

            <!-- Apellidos Field -->
            <div class="form-group col-sm-6">
                <?php echo Form::label('apellidos', 'Apellidos:'); ?>

                <?php if(isset($matricula->alumno)): ?>
                <?php echo Form::text('apellidos', $matricula->alumno->apellidos, ['class' => 'form-control']); ?>

                <?php else: ?>
                <?php echo Form::text('apellidos', null, ['class' => 'form-control']); ?>

                <?php endif; ?>
            </div>

            <!-- Dni Field -->
            <div class="form-group col-sm-6">
                <?php echo Form::label('dni', 'Dni:'); ?>

                <?php if(isset($matricula->alumno)): ?>
                <?php echo Form::text('dni', $matricula->alumno->dni, ['class' => 'form-control']); ?>

                <?php else: ?>
                <?php echo Form::text('dni', null, ['class' => 'form-control']); ?>

                <?php endif; ?>
            </div>

            <!-- Sexo Field -->
            <div class="form-group col-sm-6">
                <?php echo Form::label('sexo', 'Sexo:'); ?>

                <?php if(isset($matricula->alumno)): ?>
                <?php echo Form::select('sexo',['' => 'Seleccionar Sexo','Masculino' => 'Masculino', 'Femenino' => 'Femenino'], $matricula->alumno->sexo, ['class' => 'form-control']); ?>

                <?php else: ?>
                <?php echo Form::select('sexo',['' => 'Seleccionar Sexo','Masculino' => 'Masculino', 'Femenino' => 'Femenino'], null, ['class' => 'form-control']); ?>

                <?php endif; ?>
            </div>

            <!-- Fecha Nacimiento Field -->
            <div class="form-group col-sm-6">
                <?php echo Form::label('fecha_nacimiento', 'Fecha Nacimiento:'); ?>

                <?php if(isset($matricula->alumno)): ?>
                <?php echo Form::text('fecha_nacimiento', date("d-m-Y", strtotime($matricula->alumno->fecha_nacimiento)), ['class' => 'form-control','id'=>'datepicker']); ?>

                <?php else: ?>
                <?php echo Form::text('fecha_nacimiento', null, ['class' => 'form-control','id'=>'datepicker']); ?>

                <?php endif; ?>
            </div>

            <!-- Direccion Field -->
            <div class="form-group col-sm-6">
                <?php echo Form::label('direccion', 'Direccion:'); ?>

                <?php if(isset($matricula->alumno)): ?>
                <?php echo Form::text('direccion', $matricula->alumno->direccion, ['class' => 'form-control']); ?>

                <?php else: ?>
                <?php echo Form::text('direccion', null, ['class' => 'form-control']); ?>

                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="box box-danger">
    <div class="box-header with-border">
        <h3 class="box-title">Datos del Apoderado</h3>
    </div>
    <div class="box-body">
        <div class="row">
            <!-- Dni Field -->
            <div class="form-group col-sm-6">
                <?php echo Form::label('dni_apoderado', 'Dni:'); ?>

                <?php if(isset($matricula->apoderado)): ?>
                <?php echo Form::text('dni_apoderado', $matricula->apoderado->dni_apoderado, ['class' => 'form-control']); ?>

                <?php else: ?>
                <?php echo Form::text('dni_apoderado', null, ['class' => 'form-control']); ?>

                <?php endif; ?>
            </div>
            <!-- Nombres Field -->
            <div class="form-group col-sm-6">
                <?php echo Form::label('nombres_a', 'Nombres:'); ?>

                <?php if(isset($matricula->apoderado)): ?>
                <?php echo Form::text('nombres_a', $matricula->apoderado->nombres_a, ['class' => 'form-control']); ?>

                <?php else: ?>
                <?php echo Form::text('nombres_a', null, ['class' => 'form-control']); ?>

                <?php endif; ?>
            </div>

            <!-- Apellidos Field -->
            <div class="form-group col-sm-6">
                <?php echo Form::label('apellidos_a', 'Apellidos:'); ?>

                <?php if(isset($matricula->apoderado)): ?>
                <?php echo Form::text('apellidos_a', $matricula->apoderado->apellidos_a, ['class' => 'form-control']); ?>

                <?php else: ?>
                <?php echo Form::text('apellidos_a', null, ['class' => 'form-control']); ?>

                <?php endif; ?>
            </div>

            <!-- Telefono Field -->
            <div class="form-group col-sm-6">
                <?php echo Form::label('telefono', 'Telefono:'); ?>

                <?php if(isset($matricula->apoderado)): ?>
                <?php echo Form::text('telefono', $matricula->apoderado->telefono, ['class' => 'form-control']); ?>

                <?php else: ?>
                <?php echo Form::text('telefono', null, ['class' => 'form-control']); ?>

                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="box box-danger">
    <div class="box-header with-border">
        <h3 class="box-title">Registro de Matricula</h3>
    </div>
    <div class="box-body">
        <div class="row">
            <!-- Colegio Procedencia Field -->
            <div class="form-group col-sm-6">
                <?php echo Form::label('colegio_procedencia', 'Colegio Procedencia:'); ?>

                <?php echo Form::text('colegio_procedencia', null, ['class' => 'form-control']); ?>

            </div>

            <!-- Grado Field -->
            <div class="form-group col-sm-6">
                <?php echo Form::label('idgrado', 'Grado:'); ?>

                <?php echo Form::select('idgrado',$listGrado, null, ['class' => 'form-control select2' ,'onchange' => 'setSeccion()']); ?>

            </div>

            <!-- Grado Field -->
            <div class="form-group col-sm-12">
                <?php echo Form::label('idaula', 'Seccion:'); ?>

                <?php echo Form::select('idaula',['' => 'Seleccionar Seccion'], null, ['class' => 'form-control select2']); ?>

            </div>

            <!-- Submit Field -->
            <div class="form-group col-sm-12">
                <?php echo Form::submit('Guardar', ['class' => 'btn btn-danger']); ?>

                <a href="<?php echo e(route('matriculas.index')); ?>" class="btn btn-default">Cancelar</a>
            </div>

            <?php echo Form::hidden('idalumno', null, ['class' => 'form-control']); ?>

            <?php echo Form::hidden('idapoderado', null, ['class' => 'form-control']); ?>

        </div>
    </div>
</div><?php /**PATH /home/eozckcvw/infoelite.misistema99.com/resources/views/matriculas/fields.blade.php ENDPATH**/ ?>