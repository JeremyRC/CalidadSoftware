<!-- Idgrado Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('idgrado', 'Grado:'); ?>

    <p><?php echo e($aula->grado->descripcion); ?></p>
</div>

<!-- Seccion Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('seccion', 'Seccion:'); ?>

    <p><?php echo e($aula->seccion); ?></p>
</div>

<!-- Created At Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('created_at', 'Creado en:'); ?>

    <p><?php echo e($aula->created_at); ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('updated_at', 'Actualizado en:'); ?>

    <p><?php echo e($aula->updated_at); ?></p>
</div>

<div class="form-group col-sm-12">
    <a href="<?php echo e(route('aulas.index')); ?>" class="btn btn-default">Atras</a>
</div><?php /**PATH C:\Users\DIEGO\Desktop\Diego\laravel\infoelite\resources\views/aulas/show_fields.blade.php ENDPATH**/ ?>