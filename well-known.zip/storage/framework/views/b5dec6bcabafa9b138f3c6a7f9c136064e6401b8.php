<!-- Name Field -->
<div class="form-group col-sm-4">
    <?php echo Form::label('name', 'Nombres:'); ?>

    <p><?php echo e($users->name); ?></p>
</div>

<!-- Email Field -->
<div class="form-group col-sm-4">
    <?php echo Form::label('email', 'Correo:'); ?>

    <p><?php echo e($users->email); ?></p>
</div>

<!-- Privilegio Field -->
<div class="form-group col-sm-4">
    <?php echo Form::label('idprivilegio', 'Privilegio:'); ?>

    <p><?php echo e($users->privilegio->nombre); ?></p>
</div>

<!-- Created At Field -->
<div class="form-group col-sm-4">
    <?php echo Form::label('created_at', 'Creado en:'); ?>

    <p><?php echo e(date("d/m/Y h:i a", strtotime($users->created_at))); ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group col-sm-8">
    <?php echo Form::label('updated_at', 'Actualizado en:'); ?>

    <p><?php echo e(date("d/m/Y h:i a", strtotime($users->updated_at))); ?></p>
</div>
<?php /**PATH /home/eozckcvw/infoelite.misistema99.com/resources/views/users/show_fields.blade.php ENDPATH**/ ?>