<div class="box box-danger">
    <div class="box-header with-border">
        <h3 class="box-title">Datos del Estudiante</h3>
    </div>
    <div class="box-body">
        <div class="row" style="padding-left: 20px">
            <!-- Nombre Field -->
            <div class="form-group col-sm-6">
                <?php echo Form::label('nombre', 'Nombre:'); ?>

                <p><?php echo e($matricula->alumno->nombre); ?></p>
            </div>

            <!-- Apellidos Field -->
            <div class="form-group col-sm-6">
                <?php echo Form::label('apellidos', 'Apellidos:'); ?>

                <p><?php echo e($matricula->alumno->apellidos); ?></p>
            </div>

            <!-- Dni Field -->
            <div class="form-group col-sm-6">
                <?php echo Form::label('dni', 'Dni:'); ?>

                <p><?php echo e($matricula->alumno->dni); ?></p>
            </div>

            <!-- Sexo Field -->
            <div class="form-group col-sm-6">
                <?php echo Form::label('sexo', 'Sexo:'); ?>

                <p><?php echo e($matricula->alumno->sexo); ?></p>
            </div>

            <!-- Fecha Nacimiento Field -->
            <div class="form-group col-sm-6">
                <?php echo Form::label('fecha_nacimiento', 'Fecha Nacimiento:'); ?>

                <p><?php echo e(date("d/m/Y", strtotime($matricula->alumno->fecha_nacimiento))); ?></p>
            </div>

            <!-- Direccion Field -->
            <div class="form-group col-sm-6">
                <?php echo Form::label('direccion', 'Direccion:'); ?>

                <p><?php echo e($matricula->alumno->direccion); ?></p>
            </div>
        </div>
    </div>
</div>

<div class="box box-danger">
    <div class="box-header with-border">
        <h3 class="box-title">Datos del Apoderado</h3>
    </div>
    <div class="box-body">
        <div class="row" style="padding-left: 20px">
            <!-- Dni Field -->
            <div class="form-group col-sm-6">
                <?php echo Form::label('dni_apoderado', 'Dni:'); ?>

                <p><?php echo e($matricula->apoderado->dni_apoderado); ?></p>
            </div>
            <!-- Nombres Field -->
            <div class="form-group col-sm-6">
                <?php echo Form::label('nombres_a', 'Nombres:'); ?>

                <p><?php echo e($matricula->apoderado->nombres_a); ?></p>
            </div>

            <!-- Apellidos Field -->
            <div class="form-group col-sm-6">
                <?php echo Form::label('apellidos_a', 'Apellidos:'); ?>

                <p><?php echo e($matricula->apoderado->apellidos_a); ?></p>
            </div>

            <!-- Telefono Field -->
            <div class="form-group col-sm-6">
                <?php echo Form::label('telefono', 'Telefono:'); ?>

                <p><?php echo e($matricula->apoderado->telefono); ?></p>
            </div>
        </div>
    </div>
</div>

<div class="box box-danger">
    <div class="box-header with-border">
        <h3 class="box-title">Datos de Matricula</h3>
    </div>
    <div class="box-body">
        <div class="row" style="padding-left: 20px">
            <!-- Colegio Procedencia Field -->
            <div class="form-group col-sm-6">
                <?php echo Form::label('colegio_procedencia', 'Colegio Procedencia:'); ?>

                <p><?php echo e($matricula->colegio_procedencia); ?></p>
            </div>

            <!-- Grado Field -->
            <div class="form-group col-sm-6">
                <?php echo Form::label('idgrado', 'Grado:'); ?>

                <p><?php echo e($matricula->grado->descripcion); ?></p>
            </div>

            <!-- Idaula Field -->
            <div class="form-group col-sm-6">
                <?php echo Form::label('idaula', 'Aula:'); ?>

                <?php if(isset($matricula->aula->seccion)): ?>
                <p><?php echo e($matricula->aula->seccion); ?></p>
                <?php else: ?>
                <p>PENDIENTE</p>
                <?php endif; ?>
            </div>

            <!-- Created At Field -->
            <div class="form-group col-sm-6">
                <?php echo Form::label('created_at', 'Creado en:'); ?>

                <p><?php echo e(date("d/m/Y h:i a", strtotime($matricula->created_at))); ?></p>
            </div>

            <!-- Updated At Field -->
            <div class="form-group col-sm-6">
                <?php echo Form::label('updated_at', 'Actualizado en:'); ?>

                <p><?php echo e(date("d/m/Y h:i a", strtotime($matricula->updated_at))); ?></p>
            </div>
        </div>
    </div>
</div><?php /**PATH /home/eozckcvw/infoelite.misistema99.com/resources/views/matriculas/show_fields.blade.php ENDPATH**/ ?>