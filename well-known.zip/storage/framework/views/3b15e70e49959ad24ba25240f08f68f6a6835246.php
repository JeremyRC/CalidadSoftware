<div class="table-responsive">
    <table class="table" id="alumnos-table">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Apellidos</th>
                <th>Dni</th>
                <th>Sexo</th>
                <th>Fecha Nacimiento</th>
                <th>Direccion</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($alumno->nombre); ?></td>
                <td><?php echo e($alumno->apellidos); ?></td>
                <td><?php echo e($alumno->dni); ?></td>
                <td><?php echo e($alumno->sexo); ?></td>
                <td><?php echo e($alumno->fecha_nacimiento); ?></td>
                <td><?php echo e($alumno->direccion); ?></td>
                <td>
                    <?php echo Form::open(['route' => ['alumnos.destroy', $alumno->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('alumnos.show', [$alumno->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                        <a href="<?php echo e(route('alumnos.edit', [$alumno->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                        <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div><?php /**PATH C:\Users\DIEGO\Desktop\Diego\laravel\infoelite\resources\views/alumnos/table.blade.php ENDPATH**/ ?>