<!-- Idgrado Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('idgrado', 'Grado:'); ?>

    <?php echo Form::select('idgrado',$listGrado, null, ['class' => 'form-control']); ?>

</div>

<!-- Seccion Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('seccion', 'Seccion:'); ?>

    <?php echo Form::text('seccion', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Guardar', ['class' => 'btn btn-danger']); ?>

    <a href="<?php echo e(route('aulas.index')); ?>" class="btn btn-default">Cancelar</a>
</div><?php /**PATH /home/eozckcvw/infoelite.misistema99.com/resources/views/aulas/fields.blade.php ENDPATH**/ ?>