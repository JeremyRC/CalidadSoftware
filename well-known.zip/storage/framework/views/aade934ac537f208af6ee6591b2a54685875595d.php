<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1>
        Matricula
    </h1>
</section>
<div class="content">
    <?php echo $__env->make('matriculas.show_fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <a href="<?php echo e(route('matriculas.index')); ?>" class="btn btn-default">Atras</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/eozckcvw/infoelite.misistema99.com/resources/views/matriculas/show.blade.php ENDPATH**/ ?>