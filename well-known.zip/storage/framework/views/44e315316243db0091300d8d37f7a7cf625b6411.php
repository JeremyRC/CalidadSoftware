<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1>
        Matricula
    </h1>
</section>
<div class="content">
    <?php echo $__env->make('adminlte-templates::common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo Form::open(['route' => 'matriculas.store']); ?>


    <?php echo $__env->make('matriculas.fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo Form::close(); ?>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DIEGO\Desktop\Diego\laravel\infoelite\resources\views/matriculas/create.blade.php ENDPATH**/ ?>