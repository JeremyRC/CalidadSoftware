<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1>
        Usuarios
    </h1>
</section>
<div class="content">
    <?php echo $__env->make('adminlte-templates::common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="box box-danger">
        <div class="box-body">
            <div class="row">
                <?php echo Form::model($users, ['route' => ['users.update', $users->id], 'method' => 'patch']); ?>


                <?php echo $__env->make('users.fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/eozckcvw/infoelite.misistema99.com/resources/views/users/edit.blade.php ENDPATH**/ ?>